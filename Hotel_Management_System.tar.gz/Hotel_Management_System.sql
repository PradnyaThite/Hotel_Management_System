create database Hotel_Management_System;
CREATE TABLE Rooms (
    RoomID INT PRIMARY KEY,
    RoomNumber INT,
    RoomType VARCHAR(255),
    Rate DECIMAL(10, 2)
);
CREATE TABLE Guests (
    GuestID INT PRIMARY KEY,
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Email VARCHAR(255),
    PhoneNumber VARCHAR(15)
);
CREATE TABLE Reservations (
    ReservationID INT PRIMARY KEY,
    GuestID INT,
    RoomID INT,
    CheckInDate DATE,
    CheckOutDate DATE,
    FOREIGN KEY (GuestID) REFERENCES Guests(GuestID),
    FOREIGN KEY (RoomID) REFERENCES Rooms(RoomID)
);
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Position VARCHAR(255),
    Salary DECIMAL(10, 2)
);
select * from Rooms;
select *from Guests;
select * from Reservations;
select * from Employees;



